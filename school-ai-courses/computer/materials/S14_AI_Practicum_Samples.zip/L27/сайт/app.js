document.querySelector("h1").insertAdjacentHTML("afterend", "<p id='card'>Экспонат: бумажный робот</p>");
